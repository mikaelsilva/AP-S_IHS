#include <unistd.h>
#include <fcntl.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <stdint.h>
#include <fcntl.h>
#include <omp.h>
#include <linux/kd.h>

extern int decodifica_botao(int);

#define r_botao 1
#define r_switch 0

#define w_Displayright 0
#define w_Displayleft 1
#define w_ledG 2
#define w_ledR 3



#define modo_imortal 0
#define modo_medio 1
#define modo_dificil 2
#define modo_livre 3

#define s_escolheMusica 1
#define s_escolheModo 0
#define s_jogando 2
#define s_sair 3




#define C1  33
#define CS1 35
#define D1  37
#define DS1 39
#define E1  41
#define F1  44
#define FS1 46
#define G1  49
#define GS1 52
#define A1  55
#define AS1 58
#define B1 62

#define C2  65
#define CS2 69
#define D2  73
#define DS2 78
#define E2  82
#define F2  87
#define FS2 93
#define G2  98
#define GS2 104
#define A2  110
#define AS2 117
#define B2  123

#define C3  131
#define CS3 139
#define D3  147
#define DS3 156
#define E3  165
#define F3  175
#define FS3 185
#define G3  196
#define GS3 208
#define A3  220
#define AS3 233
#define B3  247

#define C4  262
#define CS4 277
#define D4  294
#define DS4 311
#define E4  330
#define F4  349
#define FS4 370
#define G4  392
#define GS4 415
#define A4  440
#define AS4 466
#define B4  494

#define C5  523
#define CS5 554
#define D5  587
#define DS5 622
#define E5  659
#define F5  698
#define FS5 740
#define G5  784
#define GS5 831
#define A5  880
#define AS5 932
#define B5  988

#define C6  1047
#define CS6 1109
#define D6  1175
#define DS6 1245
#define E6  1319
#define F6  1397
#define FS6 1480
#define G6  1568
#define GS6 1661
#define A6  1760
#define AS6 1865
#define B6  1976

#define C7  2093
#define CS7 2217
#define D7  2349
#define DS7 2489
#define E7  2637
#define F7  2794
#define FS7 2960
#define G7  3136
#define GS7 3322
#define A7  3520
#define AS7 3729
#define B7  3951

#define C8  4186
#define CS8 4435
#define D8  4699
#define DS8 4978

#define Oitava_1 7
#define Oitava_2 11
#define Oitava_3 15
#define Oitava_4 23
#define Oitava_5 28


#define Oitava_6 33
#define Oitava_7 38
#define Oitava_8 43

#define Nota_C 8
#define Nota_CS 13
#define Nota_D 19
#define Nota_DS 23
#define Nota_E 28
#define Nota_F 33
#define Nota_FS 38
#define Nota_G 43
#define Nota_GS 49
#define Nota_A 53
#define Nota_AS 58
#define Nota_B 68

#define Pin_Oitava_1 22
#define Pin_Oitava_2 24
#define Pin_Oitava_3 26
#define Pin_Oitava_4 28
#define Pin_Oitava_5 30
#define Pin_Oitava_6 32
#define Pin_Oitava_7 34
#define Pin_Oitava_8 36

#define Pin_Nota_C 23
#define Pin_Nota_D 25
#define Pin_Nota_E 27
#define Pin_Nota_F 29
#define Pin_Nota_G 31
#define Pin_Nota_A 33
#define Pin_Nota_B 47
#define Pin_Nota_CS 37
#define Pin_Nota_DS 39
#define Pin_Nota_FS 41
#define Pin_Nota_GS 43
#define Pin_Nota_AS 45

#define pino_trigger 50
#define pino_echo 51

#define pino_trigger2 48
#define pino_echo2 49





int notas[13][9]={{0,0,0,0,0,0,0,0,0},{0,A1,A2,A3,A4,A5,A6,A7,0},{0,B1,B2,B3,B4,B5,B6,B7,0},{0,C1,C2,C3,C4,C5,C6,C7,C8},{0,D1,D2,D3,D4,D5,D6,D7,D8},
                  {0,E1,E2,E3,E4,E5,E6,E7,0},{0,F1,F2,F3,F4,F5,F6,F7,0},{0,G1,G2,G3,G4,G5,G6,G7,0},{0,CS1,CS2,CS3,CS4,CS5,CS6,CS7,CS8},{0,DS1,DS2,DS3,DS4,DS5,DS6,DS7,DS8},
                  {0,FS1,FS2,FS3,FS4,FS5,FS6,FS7,0},{0,GS1,GS2,GS3,GS4,GS5,GS6,GS7,0},{0,AS1,AS2,AS3,AS4,AS5,AS6,AS7,0}};





unsigned char hexdigit[] = {0x3F, 0x06, 0x5B, 0x4F,
                            0x66, 0x6D, 0x7D, 0x07, 
                            0x7F, 0x6F, 0x77, 0x7C,
			                 0x39, 0x5E, 0x79, 0x71, 0x1};

 /* reverse:  reverse string s in place */
void reverse(char s[]){
     int i, j;
     char c;
 
     for (i = 0, j = strlen(s)-1; i<j; i++, j--) {
         c = s[i];
         s[i] = s[j];
         s[j] = c;
     }
}

void itoa(int n, char s[]){
     int i, sign;
 
     if ((sign = n) < 0)  /* record sign */
         n = -n;          /* make n positive */
     i = 0;
     do {       /* generate digits in reverse order */
         s[i++] = n % 10 + '0';   /* get next digit */
     } while ((n /= 10) > 0);     /* delete it */
     if (sign < 0)
         s[i++] = '-';
     s[i] = '\0';
     reverse(s);
}

int main(int argc, char *argv[]) {
 uint32_t write_var = 0x40404040;
  uint32_t marcos = 0x46060E42; 
  uint32_t read_var = 0;
  uint32_t imortal = 0;
  uint32_t livre = 0x40404040;
  uint32_t dificil = 0;
  uint32_t  medio = 0;
  uint32_t acendeG = 0xFF;
  uint32_t acendeR = 0xFFFFF;
  uint32_t apaga = 0;
 unsigned char aux2;
 int dev = open("/dev/de2i150_altera", O_RDWR);

 //write(dev, &write_var, 0);


 int i=0, j=0,  old_j =150;
 int estado = 0, modo_selecionado = 0;
 char musica[50] = "music";

 char oitava;
 char nota;
 int tempo;
 int temp;
 ssize_t total,aux;
 
  clock_t start, atual;
 char sNome[] = "music2.txt";
 int lidos=0,k=0;	
 char string[100];
char rodar[10] = "";

 unsigned char c='D';
 FILE *arq;
            		double elapsed;

  int fd = open("/dev/tty10", O_RDONLY),h;
  
  read(dev,&read_var,r_botao);
  write(dev,&write_var,w_Displayright);
  write(dev,&write_var,w_Displayright);

 for (i=0; i>-1; i++) {
    
   switch(estado){
          case s_escolheModo:

            printf("escolha o modo de jogo\n");
            read(dev, &j, r_botao);
            j = decodifica_botao(j);
              if(j < 4){
                modo_selecionado = j;
                write(dev,&j,0);
                printf("modo selecionado = %d\n",modo_selecionado);
                estado = s_escolheMusica;
                read(dev,&j,r_botao);
                k = hexdigit[modo_selecionado & 0xF]
                | (hexdigit[(modo_selecionado >>  4) & 0xF] << 8)
                | (hexdigit[(modo_selecionado >>  8) & 0xF] << 16)
                | (hexdigit[(modo_selecionado >> 12) & 0xF] << 24);
                k = ~k;
          write(dev,&k,w_Displayright);
          write(dev,&acendeR,w_ledR);

          }
          break;

          case s_escolheMusica:

            printf("escolhendo a musica do jogo\n");
            read(dev,&j, r_switch);
            //write(dev,&j,w_Displayleft);
            //ESCREVER NO DISPLAY
            if(j != 0){

            char num[15];
            itoa(j,num);
            char musica[50] = "music";
            strcat(musica,num);
            strcat(musica,".txt");
            printf("%s\n",musica);
            strcpy(sNome,musica);
            read(dev,&j, r_botao);
            j = decodifica_botao(j);
            
            while(j == 4){
            read(dev,&j, r_botao);
            j = decodifica_botao(j);
           // printf ("Aperte o botao para confirmar\n",j);
            }  
              estado = s_jogando;
              start=clock();
        }
                
          break;

          case s_jogando:
              
  		write(dev,&apaga,w_ledR);   
            switch(modo_selecionado){
            case modo_livre: 
            srand(time(NULL));  
            arq = fopen(sNome,"rt");
   			
   			
            
		 	while( (fscanf(arq,"%c %c %d ", &nota, &oitava, &tempo)) != EOF ){
  		 	printf("%c %c %c \n", nota, oitava, tempo);
  		 	int i = ((int)(nota-'A')+1);
			int j = ((int)(oitava-'1')+1);
			 
       read(dev,&j,r_switch);
			/*if(nota != 'P' && j < 4){ 
  		 	ioctl(fd, KIOCSOUND, (notas[i][j]));//coloca os valores pra tocar no buzzer
    		usleep(100*tempo);//da um sleep de i milisegundos
			ioctl(fd, KIOCSOUND,0);
			usleep(100*tempo);
			}*/
		}
    		

			fclose(arq);
              break;

            case modo_imortal:

          
            		printf("imortal\n");
            		write(dev,&acendeG,w_ledG);
   				    start=clock();
    				while(elapsed < 1.0){
    						atual = clock();
    					elapsed = (atual-start)/CLOCKS_PER_SEC;
    				}

            		write(dev,&apaga,w_ledG);
            		 start=clock();
    				while(elapsed < 1.0){
    						atual = clock();
    					elapsed = (atual-start)/CLOCKS_PER_SEC;
    					}

    					read(dev,&j,r_botao);
    					j=decodifica_botao(j);

    					if(j<4){
    						modo_selecionado = 5;
    					}
            		
            		
            		printf ("Jogando o modo imortal\n");
            		strcpy(rodar,"./f ");
            		strcat(rodar,sNome);
              		system(rodar);
            		
            	
            
              
              break;
            case modo_medio:
               // printf ("Jogando no modo medio\n");
           
            		
            		printf("medio\n");
            		write(dev,&acendeG,w_ledG);
            		double elapsed;
   				    start=clock();
    				while(elapsed < 1.0){
    						atual = clock();
    					elapsed = (atual-start)/CLOCKS_PER_SEC;
    					}
            		write(dev,&apaga,w_ledG);
            		 start=clock();
    				while(elapsed < 1.0){
    						atual = clock();
    					elapsed = (atual-start)/CLOCKS_PER_SEC;
    					}


            		
            		
            		printf ("Jogando o modo medio\n");
            		strcpy(rodar,"./h ");
            		strcat(rodar,sNome);
              	system (rodar);
            		
            	            
              break;

            case modo_dificil:
           
        		printf("dificil\n");
        		write(dev,&acendeG,w_ledG);
				    start=clock();
				while(elapsed < 1.0){
						atual = clock();
					elapsed = (atual-start)/CLOCKS_PER_SEC;
					}
        		write(dev,&apaga,w_ledG);
        		 start=clock();
				while(elapsed < 1.0){
						atual = clock();
					elapsed = (atual-start)/CLOCKS_PER_SEC;
					
        		}
        		
        		printf ("Jogando o modo dificil\n");
        		strcpy(rodar,"./g ");
        		strcat(rodar,sNome);
          		system(rodar);
              break;

            default:
            printf ("ESTA AQUI\n");
              break;
            }

          break;
          
        default:
        break;
 }
  }
       

  close(dev);
  return 0;
}



